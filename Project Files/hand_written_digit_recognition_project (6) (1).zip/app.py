import streamlit as st
import numpy as np
import tensorflow as tf
import cv2
model = tf.keras.models.load_model('/content/hand_written_Digit_recog_model.keras')

st.header('Hand Digit Recognition Model')

img = st.text_input('Enter Image Name')

def predict_digit(img_name):
  image = cv2.imread(img_name, cv2.IMREAD_GRAYSCALE)
  if image is None:
    return f"Error:could not load image'{img_name}'"
  image = cv2.resize(image, (28, 28))
  image = image.astype('float32') / 255.0
  image = np.expand_dims(image, axis=0)
  output = model.predict(image)

  stn = 'Digit in the Image is '
  st.markdown(stn)
  st.image(img_name,width=300)
  return None

result=None
if img: # Check if the user has entered an image name
    result = predict_digit(img)
if result and result.startswith("Error"): # Display error if image loading failed
    st.error(result)
